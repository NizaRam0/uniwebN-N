<?php
session_start();
if (!isset($_SESSION["id"])) {
    header("Location: ../front/login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Department - MediCare Hub</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <style>
        body { margin:0; font-family:'Poppins', sans-serif; background:#ffffff; }

        /* NAVBAR SAME */
        .navbar {
            display:flex; justify-content:space-between; align-items:center;
            padding:18px 60px; background:#ffffff; border-bottom:1px solid #e5e5e5;
        }
        .logo { display:flex; align-items:center; }
        .logo img { width:44px; margin-right:10px; }
        .logo span { font-size:22px; font-weight:600; color:#004c94; }
        .nav-links a {
            margin:0 18px; text-decoration:none; color:#004c94; font-weight:500;
        }
        .login-btn {
            background:#005bbb; color:white; padding:10px 22px;
            border-radius:6px; text-decoration:none; font-weight:500;
        }

        .page-title {
            text-align:center; padding:40px 0 20px;
            font-size:34px; font-weight:600; color:#003e74;
        }

        .departments-container {
            display:flex; justify-content:center; flex-wrap:wrap;
            gap:25px; padding:20px 50px 50px;
        }

        .department-card {
            width:260px; background:#eef6ff; padding:30px 20px;
            border-radius:10px; text-align:center; cursor:pointer;
            transition:0.2s; border:1px solid #d7e9ff;
            text-decoration:none;
        }
        .department-card:hover { transform:translateY(-8px); background:#e1f0ff; }
        .department-card img { width:60px; margin-bottom:15px; }
        .department-card h3 { margin:0; color:#003e74; font-size:20px; }
    </style>
</head>
<body>

<?php include "navbar.php"; ?>

<h1 class="page-title">Choose a Department</h1>

<div class="departments-container" id="dept-container">
    <p>Loading departments...</p>
</div>

<script>
// Fetch all departments dynamically
fetch("../Backend/api.php?type=departments")
  .then(res => res.json())
  .then(departments => {
      let container = document.getElementById("dept-container");
      container.innerHTML = ""; // clear old text

      departments.forEach(dep => {
          container.innerHTML += `
              <a href="Booking-doctors.php?dept=${dep.Department_id}" class="department-card">
              <img src="../medias/departimages/${dep.Photo}">
                  <h3>${dep.Department_name}</h3>
              </a>
          `;
      });
  })
  .catch(err => {
      document.getElementById("dept-container").innerHTML =
      "<p style='color:red;'>Failed to load departments.</p>";
  });
</script>

</body>
</html>
