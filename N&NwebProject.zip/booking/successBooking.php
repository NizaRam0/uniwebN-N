<?php
session_start();
require "../Backend/dbconx.php";

if (!isset($_SESSION["id"])) {
    header("Location: ../front/login.php");
    exit();
}

$patient_id = $_SESSION["id"];

// Validate GET parameters
if (!isset($_GET["doctor_id"], $_GET["date"], $_GET["time"])) {
    die("Invalid appointment confirmation.");
}

$doctor_id = intval($_GET["doctor_id"]);
$date = $_GET["date"];
$time = $_GET["time"];

// Fetch doctor info
$stmt = $pdo->prepare("SELECT First_name, Last_name, Specialty, Photo 
                       FROM Doctors WHERE Doctor_id = ?");
$stmt->execute([$doctor_id]);
$doctor = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$doctor) {
    die("Doctor not found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Confirmed - MediCare Hub</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <style>
        body { margin:0; font-family:'Poppins', sans-serif; background:#f7faff; }

        .container {
            width: 60%;
            margin:60px auto;
            padding:30px;
            background:white;
            border-radius:14px;
            text-align:center;
            border:1px solid #d7eaff;
        }

        h1 {
            font-size:32px;
            color:#005bbb;
            margin-bottom:10px;
        }

        p {
            font-size:17px;
            color:#444;
        }

        .doctor-box {
            margin-top:25px;
            display:flex;
            justify-content:center;
            align-items:center;
            gap:20px;
        }

        .doctor-box img {
            width:110px;
            height:110px;
            border-radius:50%;
            object-fit:cover;
            border:4px solid #005bbb66;
        }

        .info {
            text-align:left;
        }

        .success-icon {
            font-size:60px;
            color:#28a745;
            margin-bottom:10px;
        }

        .btn {
            display:inline-block;
            margin:20px 10px;
            padding:12px 25px;
            background:#005bbb;
            color:white;
            border-radius:8px;
            text-decoration:none;
            font-size:17px;
            font-weight:500;
        }

        .btn-secondary {
            background:#0099cc;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="success-icon">✔</div>

    <h1>Appointment Confirmed!</h1>
    <p>Your appointment has been successfully booked.</p>

    <div class="doctor-box">
        <img src="../medias/drimages/<?php echo $doctor['Photo']; ?>" alt="Doctor">

        <div class="info">
            <h3>Dr. <?php echo $doctor["First_name"] . " " . $doctor["Last_name"]; ?></h3>
            <p><?php echo $doctor["Specialty"]; ?></p>
            <p><strong>Date:</strong> <?php echo $date; ?></p>
            <p><strong>Time:</strong> <?php echo $time; ?></p>
        </div>
    </div>

    <a href="../front/patientDashboard.php" class="btn">Go to Dashboard</a>
    <a href="../front/viewAppointments.php" class="btn btn-secondary">View My Appointments</a>
</div>

</body>
</html>
