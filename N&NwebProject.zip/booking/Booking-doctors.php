<?php
session_start();
if (!isset($_SESSION["id"])) {
    header("Location: ../front/login.php");
    exit();
}

if (!isset($_GET['dept'])) {
    die("Invalid department.");
}

$dept_id = intval($_GET['dept']); // THIS IS THE REAL DEPARTMENT ID
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Doctor - MediCare Hub</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <style>
        body { margin:0; font-family:'Poppins', sans-serif; background:#ffffff; }

        /* NAVBAR */
        .navbar {
            display:flex; justify-content:space-between; align-items:center;
            padding:18px 60px; background:#ffffff; border-bottom:1px solid #e5e5e5;
        }
        .logo { display:flex; align-items:center; }
        .logo img { width:44px; margin-right:10px; }
        .logo span { font-size:22px; font-weight:600; color:#004c94; }
        .nav-links a {
            margin:0 18px; text-decoration:none; color:#004c94; font-weight:500;
        }
        .login-btn {
            background:#005bbb; color:white; padding:10px 22px;
            border-radius:6px; text-decoration:none; font-weight:500;
        }

        .title-section {
            text-align:center;
            padding:40px 0 10px;
        }
        .title-section h1 {
            font-size:34px; font-weight:600; color:#003e74;
        }
        .title-section p {
            font-size:16px; color:#555;
        }

        .doctors-container {
            display:flex;
            justify-content:center;
            flex-wrap:wrap;
            padding:20px 40px 50px;
            gap:35px;
        }

        .doctor-card {
            width:300px;
            background:#eef6ff;
            border:1px solid #d7e9ff;
            padding:20px;
            border-radius:12px;
            text-align:center;
            transition:0.2s;
            text-decoration:none;
            color:black;
        }
        .doctor-card:hover {
            transform:translateY(-8px);
            background:#e1f0ff;
        }

        .doctor-card img {
            width:110px;
            height:110px;
            border-radius:50%;
            object-fit:cover;
            margin-bottom:15px;
            border:3px solid #005bbb50;
        }

        .doctor-card h3 {
            margin:10px 0 5px;
            color:#003e74;
            font-size:20px;
            font-weight:600;
        }

        .doctor-card span {
            color:#0074d4;
            font-size:15px;
            font-weight:500;
        }

        .schedule-btn {
            margin-top:15px;
            display:inline-block;
            padding:10px 18px;
            background:#005bbb;
            color:white;
            border-radius:6px;
            text-decoration:none;
            font-size:15px;
            font-weight:500;
        }
    </style>
</head>

<body>

<?php include "navbar.php"; ?>

<!-- PAGE TITLE -->
<div class="title-section">
    <h1 id="dept-title">Doctors</h1>
    <p>Select a doctor to view available appointment slots.</p>
</div>

<!-- DOCTORS LIST -->
<div class="doctors-container" id="doctors-container">
    <p>Loading doctors...</p>
</div>

<script>
let deptId = <?php echo $dept_id; ?>;

// GET Department Name for title
fetch("../Backend/api.php?type=department&id=" + deptId)
  .then(res => res.json())
  .then(dep => {
      document.getElementById("dept-title").innerText =
          dep.Department_name + " Doctors";
  });

// LOAD DOCTORS OF THIS DEPARTMENT
fetch("../Backend/api.php?type=doctors_by_department&id=" + deptId)
  .then(res => res.json())
  .then(doctors => {
      let box = document.getElementById("doctors-container");
      box.innerHTML = "";

      if (doctors.length === 0) {
          box.innerHTML = "<p>No doctors available in this department.</p>";
          return;
      }

      doctors.forEach(doc => {
        box.innerHTML += `
    <div class="doctor-card">
        <a href="doctor_booking.php?doctor_id=${doc.Doctor_id}" style="text-decoration:none; color:inherit;">
            <img src="../medias/drimages/${doc.Photo}">
            <h3>Dr. ${doc.First_name} ${doc.Last_name}</h3>
            <span>${doc.Specialty}</span>
        </a>

        <a href="Booking-BookingPage.php?doctor_id=${doc.Doctor_id}"
           class="schedule-btn">
           View Schedule
        </a>
    </div>
`;

      });
  })
  .catch(err => {
      document.getElementById("doctors-container").innerHTML =
          "<p style='color:red;'>Failed to load doctors.</p>";
  });
</script>

</body>
</html>
