<?php
session_start();
require "../Backend/dbconx.php";

if (!isset($_SESSION["id"])) {
    header("Location: ../front/login.php");
    exit();
}

$patient_id = $_SESSION["id"];

// Validate GET parameters
if (!isset($_GET["doctor_id"], $_GET["date"], $_GET["time"])) {
    die("Invalid appointment request.");
}

$doctor_id = intval($_GET["doctor_id"]);
$date = $_GET["date"];
$time = $_GET["time"];

// Step 1 — Fetch doctor info
$stmt = $pdo->prepare("SELECT First_name, Last_name, Specialty, Photo 
                       FROM Doctors WHERE Doctor_id = ?");
$stmt->execute([$doctor_id]);
$doctor = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$doctor) {
    die("Doctor not found.");
}

// Step 2 — Check if slot is already taken
$check = $pdo->prepare("SELECT Appointment_id FROM Appointment
                        WHERE Doctor_id = ? AND Appointment_Date = ? AND Appointment_time = ?");
$check->execute([$doctor_id, $date, $time]);

$alreadyTaken = $check->fetch();

if ($alreadyTaken) {
    die("
        <h2 style='color:red;text-align:center;margin-top:40px;'>
            Sorry, this time slot is already booked by another patient.
        </h2>
        <p style='text-align:center;'>
            <a href='doctor_booking.php?doctor_id=$doctor_id'>Choose another time</a>
        </p>
    ");
}

// Step 3 — If confirmed (POST), insert appointment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $reason = isset($_POST["reason"]) ? trim($_POST["reason"]) : "General Checkup";

    $insert = $pdo->prepare("
        INSERT INTO Appointment (Appointment_Date, Appointment_time, Reason, Status, Patient_id, Doctor_id)
        VALUES (?, ?, ?, 'Scheduled', ?, ?)
    ");

    $insert->execute([$date, $time, $reason, $patient_id, $doctor_id]);

    header("Location: successBooking.php?doctor_id=$doctor_id&date=$date&time=$time");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Appointment - MediCare Hub</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <style>
        body { margin:0; font-family:'Poppins', sans-serif; background:#f7faff; }
        .container {
            width: 60%; margin:50px auto; background:white; padding:30px;
            border-radius:12px; border:1px solid #d8e7ff;
        }
        h1 { color:#003e74; }
        .doctor-info {
            display:flex; align-items:center; gap:20px; margin:20px 0;
        }
        .doctor-info img {
            width:110px; height:110px; border-radius:50%; object-fit:cover;
            border:3px solid #005bbb44;
        }
        .label { font-weight:600; color:#003e74; }
        textarea {
            width:100%; height:90px; padding:10px; border:1px solid #c7dfff;
            border-radius:8px; resize:none; margin-top:10px;
        }
        .confirm-btn {
            display:block; width:220px; margin:20px auto; text-align:center;
            padding:12px 0; background:#005bbb; color:white;
            border-radius:8px; text-decoration:none; font-size:18px; font-weight:500;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Confirm Your Appointment</h1>

    <div class="doctor-info">
        <img src="../medias/drimages/<?php echo $doctor['Photo']; ?>" alt="Doctor">
        <div>
            <h2>Dr. <?php echo $doctor["First_name"] . " " . $doctor["Last_name"]; ?></h2>
            <p><?php echo $doctor["Specialty"]; ?></p>
        </div>
    </div>

    <p><span class="label">Date:</span> <?php echo $date; ?></p>
    <p><span class="label">Time:</span> <?php echo $time; ?></p>

    <!-- Reason Input -->
    <form method="POST">
        <label class="label">Reason for visit (optional):</label>
        <textarea name="reason" placeholder="Describe your symptoms or the reason for booking..."></textarea>

        <button type="submit" class="confirm-btn">Confirm Appointment</button>
    </form>
</div>

</body>
</html>
