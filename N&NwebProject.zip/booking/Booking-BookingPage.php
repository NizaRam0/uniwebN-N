<?php
session_start();
if (!isset($_SESSION["id"])) {
    header("Location: ../front/login.php");
    exit();
}
$isLoggedIn = isset($_SESSION["id"]);

if (!isset($_GET['doctor_id'])) {
    die("Doctor not found.");
}

$doctor_id = intval($_GET['doctor_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Appointment - MediCare Hub</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <style>
        body{ margin:0; font-family:'Poppins', sans-serif; background:#f7faff; }
        .navbar{ display:flex; justify-content:space-between; padding:18px 60px; border-bottom:1px solid #e5e5e5; background:white; }
        .navbar img{ width:16%; }
        .login-btn{ background:#005bbb; color:white; padding:10px 22px; text-align:center; border-radius:6px; text-decoration:none; }
        .doctor-header{
            display:flex; align-items:center; gap:25px;
            background:#eef6ff; border:1px solid #d7e9ff;
            margin:40px auto; padding:25px 40px; width:80%;
            border-radius:12px;
        }
        .doctor-header img{
            width:130px; height:130px; border-radius:50%;
            object-fit:cover; border:4px solid #005bbb66;
        }
        .date-section, .slots-section{ width:80%; margin:20px auto; }
        .date-list{ display:flex; gap:15px; overflow-x:auto; }
        .date-item{
            min-width:120px; background:white; border:1px solid #d0e3ff;
            text-align:center; padding:15px; border-radius:10px;
            cursor:pointer; transition:0.2s;
        }
        .date-item.active{ background:#005bbb; color:white; }
        .slots-grid{ display:flex; flex-wrap:wrap; gap:15px; }
        .slot{
            padding:12px 20px; background:white; border-radius:8px;
            border:1px solid #d7eaff; cursor:pointer;
        }
        .slot.unavailable{ background:#eee !important; color:#777; cursor:not-allowed; }
        .slot.selected{ background:#005bbb; color:white; }
        .book-btn{
            display:block; width:260px; margin:40px auto;
            padding:14px; background:#005bbb; color:white; text-align:center;
            border-radius:8px; text-decoration:none; font-size:18px;
        }
    </style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <img src="../medias/logo.png">
        <a class="login-btn" href="../front/patientDashboard.php">Dashboard</a>
   
</div>

<!-- DOCTOR HEADER -->
<div id="doctor-header" class="doctor-header">
    <p>Loading doctor...</p>
</div>

<!-- DATE SELECTOR -->
<div class="date-section">
    <h2>Select a Date</h2>
    <div class="date-list" id="date-list"></div>
</div>

<!-- TIME SLOTS -->
<div class="slots-section">
    <h2>Select a Time</h2>
    <div class="slots-grid" id="slots-grid"></div>
</div>

<a id="book-btn" class="book-btn" style="display:none;">Confirm Appointment</a>

<script>
let doctorId = <?php echo $doctor_id; ?>;
let selectedDate = null;
let selectedSlot = null;

// -----------------------------
// LOAD DOCTOR INFO
// -----------------------------
fetch("../Backend/api.php?type=doctor&id=" + doctorId)
.then(res => res.json())
.then(doc => {
    document.getElementById("doctor-header").innerHTML = `
        <img src="../medias/drimages/${doc.Photo}" />
        <div class="doc-info">
            <h1>Dr. ${doc.First_name} ${doc.Last_name}</h1>
            <p>${doc.Specialty}</p>
            <p>⭐ 4.9 | 120 reviews</p>
        </div>
    `;
});


// -----------------------------
// GENERATE 14 DAYS OF DATES
// -----------------------------
function loadDates() {
    let container = document.getElementById("date-list");
    container.innerHTML = "";

    for (let i=0; i<14; i++){
        let d = new Date();
        d.setDate(d.getDate() + i);

        let label = d.toLocaleDateString("en-US", {weekday:"short", day:"numeric", month:"short"});
        let iso = d.toISOString().split("T")[0];

        let div = document.createElement("div");
        div.className = "date-item";
        div.innerHTML = label;
        div.onclick = () => selectDate(div, iso);

        container.appendChild(div);
    }
}
loadDates();


// -----------------------------
// HANDLE DATE SELECTION
// -----------------------------
function selectDate(element, isoDate){
    selectedDate = isoDate;

    document.querySelectorAll(".date-item").forEach(e => e.classList.remove("active"));
    element.classList.add("active");

    loadSlots(isoDate);
}


// -----------------------------
// LOAD SLOT TIMES FOR DATE
// -----------------------------
function loadSlots(date){
    let grid = document.getElementById("slots-grid");
    grid.innerHTML = "<p>Loading...</p>";

    Promise.all([
        fetch("../Backend/api.php?type=office_hours&id=" + doctorId).then(r => r.json()),
        fetch(`../Backend/api.php?type=taken_slots&id=${doctorId}&date=${date}`).then(r => r.json())
    ])
    .then(([hours, taken]) => {
        grid.innerHTML = "";

        if (hours.length === 0){
            grid.innerHTML = "<p>No working hours.</p>";
            return;
        }

        // Convert taken slots into a Set for quick lookup
        let takenSet = new Set(taken.map(t => t.substring(0,5)));

        // Find the matching weekday office hours
        let dayIndex = new Date(date).getDay(); // Sunday=0

        let todaysHours = hours.filter(h => h.Weekday == dayIndex);
        if (todaysHours.length === 0){
            grid.innerHTML = "<p>No available hours this day.</p>";
            return;
        }

        todaysHours.forEach(h => {
            let start = h.Start_time;
            let end = h.End_time;
            let slotLen = h.Slot_length;

            let current = start;

            while (current < end){
                let slotDiv = document.createElement("div");
                slotDiv.className = "slot";
                slotDiv.textContent = current;

                if (takenSet.has(current)){
                    slotDiv.classList.add("unavailable");
                } else {
                    slotDiv.onclick = () => selectSlot(slotDiv, current);
                }

                grid.appendChild(slotDiv);

                // Increase slot time
                let [hour, minute] = current.split(":").map(Number);
                minute += slotLen;
                if (minute >= 60){ hour++; minute -= 60; }
                current = String(hour).padStart(2,"0") + ":" + String(minute).padStart(2,"0");
            }
        });
    });
}


// -----------------------------
// HANDLE SLOT SELECTION
// -----------------------------
function selectSlot(element, time){
    selectedSlot = time;

    document.querySelectorAll(".slot").forEach(e => e.classList.remove("selected"));
    element.classList.add("selected");

    let btn = document.getElementById("book-btn");
    btn.style.display = "block";
    btn.href = `../booking/confirmBooking.php?doctor_id=${doctorId}&date=${selectedDate}&time=${selectedSlot}`;
}
</script>

</body>
</html>
